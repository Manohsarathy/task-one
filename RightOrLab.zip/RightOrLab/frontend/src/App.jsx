import React from 'react'
import DataGrid from './components/DataGrid'

const App = () => {
  return (
    <div>
      <DataGrid/>
    </div>
  )
}

export default App