exports.products = [
  { id: 1, location: "Colorado", branch: "Branch1" },
  { id: 2, location: "Florida", branch: "Branch2" },
  { id: 3, location: "Mississippi", branch: "Branch3" },
];
